/*
 * Copyright (C) 2017 FIX94
 *
 * This software may be modified and distributed under the terms
 * of the MIT license.  See the LICENSE file for details.
 */
#ifndef _WIIDRC_H_
#define _WIIDRC_H_

#define WIIDRC_BUTTON_A			0x8000
#define WIIDRC_BUTTON_B			0x4000
#define WIIDRC_BUTTON_X			0x2000
#define WIIDRC_BUTTON_Y			0x1000
#define WIIDRC_BUTTON_LEFT		0x0800
#define WIIDRC_BUTTON_RIGHT		0x0400
#define WIIDRC_BUTTON_UP		0x0200
#define WIIDRC_BUTTON_DOWN		0x0100
#define WIIDRC_BUTTON_ZL		0x0080
#define WIIDRC_BUTTON_ZR		0x0040
#define WIIDRC_BUTTON_L			0x0020
#define WIIDRC_BUTTON_R			0x0010
#define WIIDRC_BUTTON_PLUS		0x0008
#define WIIDRC_BUTTON_MINUS		0x0004
#define WIIDRC_BUTTON_HOME		0x0002

#define WIIDRC_EXTRA_BUTTON_L3	0x80
#define WIIDRC_EXTRA_BUTTON_R3	0x40
#define WIIDRC_EXTRA_BUTTON_TV	0x30

#endif
