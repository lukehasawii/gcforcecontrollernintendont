#ifndef __JVSIO_H__
#define __JVSIO_H__

#include "global.h"

void JVSIOCommand( char *DataIn, char *DataOut );

#endif
