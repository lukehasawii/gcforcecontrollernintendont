gcc main.c -m32 -s -Os -static -o bin2h
chmod a+x bin2h
