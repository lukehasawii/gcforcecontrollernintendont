/*
	Filename    : __CARDClearStatus.bin
	Date created: Fri Jul 31 19:28:10 2020
*/

#define __CARDClearStatus_size 0x8

const unsigned char __CARDClearStatus[] = {
	0x38, 0x60, 0x00, 0x00, 	0x4E, 0x80, 0x00, 0x20
};
