/*
	Filename    : ReturnMinus1.bin
	Date created: Fri Jul 31 19:29:06 2020
*/

#define ReturnMinus1_size 0x8

const unsigned char ReturnMinus1[] = {
	0x38, 0x60, 0xFF, 0xFF, 	0x4E, 0x80, 0x00, 0x20
};
