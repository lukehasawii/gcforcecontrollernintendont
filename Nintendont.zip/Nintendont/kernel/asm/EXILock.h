/*
	Filename    : EXILock.bin
	Date created: Fri Jul 31 19:28:31 2020
*/

#define EXILock_size 0x8

const unsigned char EXILock[] = {
	0x38, 0x60, 0x00, 0x01, 	0x4E, 0x80, 0x00, 0x20
};
