/*
	Filename    : Return1.bin
	Date created: Fri Jul 31 19:29:05 2020
*/

#define Return1_size 0x8

const unsigned char Return1[] = {
	0x38, 0x60, 0x00, 0x01, 	0x4E, 0x80, 0x00, 0x20
};
