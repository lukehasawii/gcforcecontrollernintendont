Small helper tool I wrote up back in 2014 used to generate the function patterns used in patches.c  
Simply copy the function data from the game executable you want to get the pattern of into a "func.bin" with a hex editor,  
place it into the same folder as NinPattern and then run NinPattern from command line to get the array data for patches.c  