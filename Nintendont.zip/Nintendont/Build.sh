#!/bin/sh
# This shell script is still here for compatibility reasons.
make forced
